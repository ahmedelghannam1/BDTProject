cd /home/cloudera/kafka_2.13-3.0.0/bin
./kafka-topics.sh --create --bootstrap-server localhost:9092 --partitions 1 --replication-factor 1 --topic tourism


