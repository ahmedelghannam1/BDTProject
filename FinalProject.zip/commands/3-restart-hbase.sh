#!/bin/sh

sudo service hbase-master restart
sudo service hbase-regionserver restart

